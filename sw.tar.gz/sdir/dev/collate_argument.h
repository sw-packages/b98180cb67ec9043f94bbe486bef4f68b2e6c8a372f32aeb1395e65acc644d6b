#pragma once

namespace sqlite_orm {
    
    namespace internal {
        
        enum class collate_argument {
            binary,
            nocase,
            rtrim,
        };
    }
    
}
